﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MordorCruelPlan.Foods
{
    class Cram:Food
    {
        public override int happinessLevel
        {
            get
            {
                return 2;
            }
        }
    }
}
