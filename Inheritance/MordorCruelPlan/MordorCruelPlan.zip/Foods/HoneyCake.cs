﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MordorCruelPlan.Foods
{
    class HoneyCake:Food
    {
        public override int happinessLevel
        {
            get
            {
                return 5;
            }
        }
    }
}
