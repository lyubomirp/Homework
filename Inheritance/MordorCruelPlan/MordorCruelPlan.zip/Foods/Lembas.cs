﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MordorCruelPlan.Foods
{
    class Lembas:Food
    {
        public override int happinessLevel
        {
            get
            {
                return 3;
            }
        }
    }
}
