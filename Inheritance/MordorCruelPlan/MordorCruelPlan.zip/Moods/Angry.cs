﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MordorCruelPlan.Moods
{
    class Angry:Mood
    {
        public override string resMood
        {
            get
            {
                return "Angry";
            }
        }
    }
}
