﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MordorCruelPlan.Moods
{
    class Happy:Mood
    {
        public override string resMood
        {
            get
            {
                return "Happy";
            }
        }
    }
}
