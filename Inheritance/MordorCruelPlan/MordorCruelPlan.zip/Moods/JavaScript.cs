﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MordorCruelPlan.Moods
{
    class JavaScript:Mood
    {
        public override string resMood
        {
            get
            {
                return "JavaScript";
            }
        }
    }
}
