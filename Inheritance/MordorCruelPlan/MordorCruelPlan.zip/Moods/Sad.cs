﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MordorCruelPlan.Moods
{
    class Sad:Mood
    {
        public override string resMood
        {
            get
            {
                return "Sad";
            }
        }
    }
}
