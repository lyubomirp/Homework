﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AnimalFarm.Foods
{
    class Meat : Food
    {
        public Meat(int quantity) : base(quantity)
        {
        }
    }
}
