﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AnimalFarm.Foods
{
    class Seeds : Food
    {
        public Seeds(int quantity) : base(quantity)
        {
        }
    }
}
