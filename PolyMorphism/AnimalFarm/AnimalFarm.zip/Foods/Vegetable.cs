﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AnimalFarm.Foods
{
    class Vegetable : Food
    {
        public Vegetable(int quantity) : base(quantity)
        {
        }
    }
}
