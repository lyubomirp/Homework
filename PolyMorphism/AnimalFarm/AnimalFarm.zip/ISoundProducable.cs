﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AnimalFarm
{
    public interface ISoundProducable
    {
        void ProduceSound();
    }
}
